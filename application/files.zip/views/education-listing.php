<?php

include 'header.php';
?>
<!--------------------------- Information Section Starts -------------->
<section class="mg-tp-60">
    <div class="container">
        <div class="row">
            <div>
                <h3 class="heading-color text-center">Education & Career Development Counselling</h3>
            </div>
            <div class="col-md-12">
               <p><b>Education</b> is a movement from darkness to light. Although education is directly connected with the economic development of the Country, sufficient education to all children of India is still not available. Without education, people continue to remain in cycles of poverty and backwardness for generations. </p>
               <p>The hierarchy of Indian education system follows a “10+2+3” educational pattern. Generally, school education is taken at near-by places. Then there are further levels of education that includes higher education i.e. <br>(i) Under-Graduate/ Bachelor’s level education, <br>(ii) Post-Graduate/Master’s level education, <br>(iii) Doctoral studies/ Ph.D. level education, <br>(iv) Vocational Education & Training, <br>(v) Certificate and Diploma programs in specialized fields.</p>
               <p>Challenges with Indian education system are many, which require counselling. Here children are deprived of the access to be better informed, the learning methodology does not equip them with skills like reasoning, problem solving, ability to self-learn, critical and independent thinking, etc.</p>
               <p>Subsequent to education is career development, which is a lifelong process. Career Counselling helps in deciding which course of study and which lucrative career to be decided according to one’s ambitious mind, interest, capabilities and the environment.  If one is looking for career change, job-hunting advice or mentoring then also career counseling shall help.</p>
           </div>
       </div>
   </section>
   <!-------------------- Information Section Ends ----------------------------------->

   <!-------- list -------->
   <section class="mg-top-bt">
    <div class="container">
     <?php 
     $id='6';
     $where='p_cat';
     $table='proffesional';
     $name=$this->Adminmodel->select_comm_where($where,$id,$table);
     foreach ($name as $value) {
      if($value['p_active']==1) { 

       ?>
       <div class="row border-bt mg-top-bt">
        <div class="col-md-4 col-12">
            <div class="img-boxsize">
                <?php
                if($value['p_image'])
                {
                    ?>
                    <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                    <?php
                }
                else
                {
                    ?>
                    <img style="width: 180px" src="<?php echo base_url() ?>/image/user.svg" class="img-responsive w180">
                    <?php
                }
                ?>

            </div>
        </div>
        <div class="col-md-6 col-12">
            <h2><?php echo $value['p_name']; ?></h2>
            <span><?php echo $value['p_destination']; ?></span>
            <br />
                    <!-- <span>2 Years</span>
                        <p class="text-justify mt-1">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, The point of using Lorem Ipsum.</p> -->
                    </div>
                    <?php if(!empty($_SESSION['sessionid'])){ ?>
                        <div class="col-md-2 col-12">
                            <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/6' );?>" class="bt-color">Submit Enquiry</a></div>
                        </div>
                    <?php } else { ?>
                     <div class="col-md-2 col-12">
                        <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/'.$value['id'].'/6' );?>" class="bt-color">Submit Enquiry</a></div>
                    </div>
                <?php } } ?>

            </div>
        <?php } ?>
    </div>
</section>
<!-------- list -------->
<?php
include 'footer.php';
?>