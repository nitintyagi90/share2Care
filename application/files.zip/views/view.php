<?php

include 'header.php';
?>

<div class="container">
  <div class="row">
   <!-- CHAT -->
   <div class="col-lg-6">
    <div class="card-box">
      <h4 class="m-t-0 m-b-20 header-title"><b>Chat</b></h4>

      <div class="chat-conversation">


       <?php $data = $query[0]['id']; 
       $comment=$this->Adminmodel->commentdatauser($data);

       ?>
       <ul class="conversation-list slimscroll-alt" style="height: 380px; min-height: 332px;">
        <?php foreach ($comment as $value) { 
         ?>
         <?php if($value['is_comment']==0){ ?>
          <li class="clearfix">
            <div class="chat-avatar">
              <img src="<?php echo $value['u_image']; ?>" alt="" style="width: 50px;height: 50px;">
              <i><?php if($value['is_comment']==0){  echo $value['date']; } ?></i>
            </div>
            <div class="conversation-text">
              <div class="ctext-wrap">
                <i><?php echo $value['u_name']; ?></i>
                <p>
                 <?php if($value['is_comment']==0){  echo $value['comment']; } ?>
               </p>
             </div>
           </div>
         </li>
       <?php } else if($value['is_comment']==1) { ?>
        <li class="clearfix odd">
          <div class="chat-avatar">
            <img src="<?php echo base_url(); ?>/image/icon.png" alt="Admin">
            <i><?php if($value['is_comment']==1){  echo $value['date']; } ?></i>
          </div>
          <div class="conversation-text">
            <div class="ctext-wrap">
              <i>Admin</i>
              <p>
               <?php if($value['is_comment']==1){  echo $value['comment']; } ?>
             </p>
           </div>
         </div>
         </li><?php } else if($value['is_comment']==2) { ?>
          <li class="clearfix odd">
            <div class="chat-avatar">
              <img src="<?php echo base_url(); ?>/image/icon.png" alt="Admin">
              <i><?php if($value['is_comment']==2){  echo $value['date']; } ?></i>
            </div>
            <div class="conversation-text">
              <div class="ctext-wrap">
                <i>Admin</i>
                <p>
                 <?php if($value['is_comment']==2){  echo $value['comment']; } ?>
               </p>
             </div>
           </div>
           </li><?php } ?>


         <?php } ?>
       </ul>
       <?php 
       $data= $query[0]['id']; 
       $admincomment=$this->Adminmodel->admincomment($data);
       if(!empty($admincomment)){
        ?>
        <div class="row">
          <div class="col-sm-9 chat-inputbar">
            <input type="text" class="form-control chat-input" placeholder="Enter your text" id="text">
          </div>
          <?php $data= $query[0]['id']; 
          $comment=$this->Adminmodel->commentdatauser($data); ?>
          <div class="col-sm-3 chat-send">
            <button type="submit" class="btn btn-md btn-info btn-block waves-effect waves-light" onclick="send();">Send</button>
          </div>

        </div>
      <?php } ?>
    </div>
  </div>

</div> <!-- end col-->

<!-- Todos app -->
<div class="col-lg-6">
  <div class="card-box">
    <h4 class="m-t-0 m-b-20 header-title text-center"><b>Professional Details</b></h4>
    <div class="text-center">
      <div class="member-card">
        <?php 
        $id = $query[0]['assigned_to'];
        $where='id';
        $table='proffesional';
        $prodetail=$this->Adminmodel->select_comm_where($where,$id,$table); 
        ?>
        

        <div class="thumb-xl member-thumb m-b-10 center-block">

          <?php
          if(isset($prodetail[0]['p_image']) && $prodetail[0]['p_image'] == base_url().'image/')
          {
            ?>
            <img style="width: 150px" src="<?php echo base_url() ?>image/user.svg" class="img-circle img-thumbnail" alt="profile-image">

            <?php
          }
          else
          {
            ?>
            <img src="<?php echo $prodetail[0]['p_image'] ?>" class="img-circle img-thumbnail" alt="profile-image">
            <?php
          }
          ?>




          <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i>
        </div>
        <div class="">
          <h4 class="m-b-5"><?php echo $prodetail[0]['p_name']; ?></h4>
          <p class="text-muted"><?php  $id=$prodetail[0]['id'];
          $where='user_id';
          $table='query';
          $query =$this->Adminmodel->select_comm_where($where,$id,$table); 
          $id=$query[0]['category'];
          $where='id';
          $table='category';
          $category =$this->Adminmodel->select_comm_where($where,$id,$table);

          echo $category[0]['name']; ?> </p>
        </div>
        <div class="text-left">
          <p class="text-muted font-13"><strong>Full Name :</strong> <span class="m-l-15"><?php echo $prodetail[0]['p_name']; ?></span></p>

          <p class="text-muted font-13"><strong>Mobile :</strong><span class="m-l-15"><?php echo $prodetail[0]['p_mobile']; ?></span></p>

          <p class="text-muted font-13"><strong>Email :</strong> <span class="m-l-15"><?php echo $prodetail[0]['p_email']; ?></span></p>

        </div>
      </div>

    </div> <!-- end card-box -->
  </div>

</div> <!-- end col -->
</div> 
</div>

<input type="hidden" id="url" value="<?php echo base_url(); ?>">   
<input type="hidden" id="queryid" value="<?php echo $comment[0]['query_id']; ?>">   
<input type="hidden" id="userid" value="<?php echo $comment[0]['user_id']; ?>">   
<input type="hidden" id="proid" value="<?php echo $comment[0]['is_assigned']; ?>">   
<?php 
$id =$comment[0]['query_id'];
$countuser=$this->Adminmodel->countuser($id); ?>

<input type="hidden" id="countuser" value="<?php echo count($countuser); ?>">
<?php
include 'footer.php';
?>
<script type="text/javascript">
  function send(){

    var urls = $("#url").val();
    var text = $("#text").val();
    var userid = $("#userid").val();
    var proid = $("#proid").val();
    var queryid = $("#queryid").val();
    var countuser=$("#countuser").val();
    var countuse =parseInt(countuser);
    if(countuse<3){
      $.ajax({

        type: "POST",

        url: urls+"Share/chat",

        data: {userid:userid,proid:proid,text:text,queryid:queryid},

        cache: false,

        success: function(result){

         window.location.reload();
       }

     });

    }else{
      alert('maximum 3 comment');
    }
  }
</script>

