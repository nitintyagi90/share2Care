<?php

include 'header.php';
?>
<!--------------------------- Information Section Starts -------------->
<section class="mg-tp-60">
    <div class="container">
        <div class="row">
            <div>

                <h3 class="heading-color text-center">Counselling by Psychologist</h3>
            </div>
            <div class="col-md-12">
                <p>Just as for physically health, there are doctors, for mental well being, it is essential to contact Psychologist, for taking care of stigma around mental health.</p>
                <p>When one (no matter what age, gender or cultural background) is unable to cope with incidences like disputes in family, break up of relationship, loss of loved one, loss in business, disputes/pressures at work place, property disputes, loneliness, pressure in studies which causes depression, stress, anxiety and shake confidence, counselling can help to provide strategies to cope with for managing such situation.</p>
                <p>Thus, <b>Counselling</b> is a talk therapy with application of psychological or human development principles that addresses wellness & personal development. A counselor is not there to advise or direct, it is to EMPOWER the needy through rationalizing of thoughts & feelings.</p>
                <p><b>Depending of situation counseling can be as follows – </b></p>
                <p><b>Individual Counselling :-&nbsp;</b>Individual counselling involves a single person that solves the emotional difficulties such as depression, anxiety, harassment, grief, trauma, low self-esteem, guilt, interpersonal problems, stress, and problems in living. It helps them to have a clear vision of their own self.</p>
                <p>Further, Adolescents or teenagers may suffers from different level of anxiety and depression, if the same remain untreated, it may lead to worse consequences like suicide or adopting criminal way of life. Adolescent counselling (as individual counseling) helps such youngsters to make sense of their feelings, thoughts and behaviour.</p>
                <p><b>Couple/Marriage Counselling :-&nbsp;</b>Fact is very few relationships exist conflict-free. Hence counseling is to resolve issues like odd tiff, full-blown arguments, and frequent fights with your partner or you have simply stopped having fun. </p>
                <p><b>Workplace Counselling :-&nbsp;</b>It is for providing a non-judgmental, empathic and accessible means to allow an employee to find a way forward by coming out of work related stress, anxiety, low in self-esteem and identify their true strength and get bounce back in their professional life with full throttle to excel and grow.</p>
                <p><b>Mental Health – </b>Anxiety, Chronic Pain, Depression, Eating Disorders, Insomnia</p>
                <p><b>Personality Problems - </b>Lack of confidence, Shyness, Develop self esteem, assertiveness, anger.</p>
                <p><b>Personal Growth - </b>Learn to Set Goals in life, Achieve Happiness in life, Develop Positive thinking</p>
                <p><b>Relationships - </b>Relationship difficulties, Combat separation or divorce</p>
                <p><b>Emotional Management – </b>Anger, Stress</p>
                <p><b>Betterment of Family Life –</b> Parenting, Fighting old age depression, Address to adolescence issues</p>
            </div>
        </div>
    </section>
    <!-------------------- Information Section Ends ----------------------------------->

    <!-------- list -------->
    <section class="mg-top-bt">
        <div class="container">
          <?php 
          $id='9';
          $where='p_cat';
          $table='proffesional';
          $name=$this->Adminmodel->select_comm_where($where,$id,$table);
          foreach ($name as $value) {
              if($value['p_active']==1) { 

               ?>
               <div class="row border-bt mg-top-bt">
                <div class="col-md-4 col-12">
                 <div class="img-boxsize">

                    <?php 
                    if(isset($value['p_image']) && $value['p_image'] != base_url().'image/' )
                    {
                        ?>
                        <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                        <?php
                    }
                    else
                    {
                        ?>
                        <img style="width: 180px" src="<?php echo base_url() ?>/image/user.svg" class="img-responsive">
                        <?php
                    }
                    ?>

                </div>
            </div>
            <div class="col-md-6 col-12">
                <h2><?php echo $value['p_name']; ?></h2>
                <span><?php echo $value['p_destination']; ?></span><br />
                <span><?php echo $value['p_experience']; ?> Years</span>
                <p class="text-justify mt-1"><?php echo $value['p_description']; ?>.</p>
            </div>
            <?php if(!empty($_SESSION['sessionid'])){ ?>
                <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/9' );?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } else { ?>
             <div class="col-md-2 col-12">
                <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/'.$value['id'].'/9' );?>" class="bt-color">Submit Enquiry</a></div>
            </div>
        <?php } ?>
    </div>
<?php } }  ?>
</div>
</section>
<!-------- list -------->
<?php
include 'footer.php';