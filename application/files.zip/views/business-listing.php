<?php

include 'header.php';
?>
  <!--------------------------- Information Section Starts -------------->
    <section class="mg-tp-60">
        <div class="container">
            <div class="row">
                <div>
                        <h3 class="heading-color text-center">Financial Management</h3>
                </div>
                <div class="col-md-12">
                    <p>Proper planning of available income options leads to better management of expenses. Financial planning fulfill your desires for larger purchases and acquisitions like car, house/shop/land,  foreign travel, and leading a financially secure life forever. Judicious planning of assets provides a good return on investment.</p>
                    <p>Senior citizens need to plan, way in advance and select schemes offered by banks, financial institution, Govt., to receive monetary benefits for living a financially secure life after retirement.</p>
                    <p>However, selecting the right mix of schemes according to your needs for profit, liquidity and safety can be a daunting task as it will take a lot of time and prove NOT to be hassle free.</p>
                    <p>A financial consultant while giving solution of your problem, will take an over-view of your<br>(i) financial status, <br>(ii) commitments, and <br>(iii) family responsibilities <br>and gives the appropriate financial recommendations. Financial planners have exhaustive knowledge and experience about the financial instruments and tools available for giving appropriate guidance and help you to select a portfolio that is just right for you.</p>
                </div>
            </div>
        </div>
    </section>
    <!-------------------- Information Section Ends ----------------------------------->

    <!-------- list -------->
    <section class="mg-top-bt">
        <div class="container">
              <?php 
            $id='11';
            $where='p_cat';
            $table='proffesional';
            $name=$this->Adminmodel->select_comm_where($where,$id,$table);
            foreach ($name as $value) {
                  if($value['p_active']==1) { 

               ?>
        <div class="row border-bt mg-top-bt">
            <div class="col-md-4 col-12">
                 <div class="img-boxsize">

                <?php 
                if(isset($value['p_image']) && $value['p_image'] != '')
                {
                    ?>
                    <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                    <?php
                }
                else
                {
                    ?>
                    <img style="width: 180px" src="<?php echo base_url() ?>/image/business.svg" class="img-responsive">
                    <?php
                }
                ?>

            </div>
            </div>
            <div class="col-md-6 col-12">
                <h2><?php echo $value['p_name']; ?></h2>
                <span><?php echo $value['p_destination']; ?></span><br />
                <span><?php echo $value['p_experience']; ?> Years</span>
                <p class="text-justify mt-1"><?php echo $value['p_description']; ?>.</p>
            </div>
             <?php if(!empty($_SESSION['sessionid'])){ ?>
                <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/11' );?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } else { ?>
                 <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/'.$value['id'].'/11' );?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } } ?>
        </div>
<?php }  ?>
        </div>
    </section>
    <!-------- list -------->
<?php
include 'footer.php';