<?php
include 'header.php';
include 'sidebar.php';
 ?>
 <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">


                        <div class="row">
                            <div class="col-xs-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">More Details</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Home</a>
                                        </li>
                                        <li class="active">
                                            View
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                            <!-- CHAT -->
                            <div class="col-lg-6">
                                <div class="card-box">
                                    <h4 class="m-t-0 m-b-20 header-title"><b>Chat</b></h4>

                                    <div class="chat-conversation">
                                       <?php $data= $query[0]['id']; 
                                       $comment=$this->Adminmodel->commentdata($data);
                                      
                                      ?>
                                        <ul class="conversation-list slimscroll-alt" style="height: 380px; min-height: 332px;">
                                            <?php foreach ($comment as $value) { 
                                               ?>
                                               <?php if($value['is_comment']==0){ ?>
                                            <li class="clearfix">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo $value['u_image']; ?>" alt="male">
                                                    <i><?php if($value['is_comment']==0){  echo $value['date']; } ?></i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i><?php echo $value['u_name']; ?></i>
                                                        <p>
                                                           <?php if($value['is_comment']==0){  echo $value['comment']; } ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php } else if($value['is_comment']==1) { ?>
                                            <li class="clearfix odd">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo base_url(); ?>/image/icon.png" alt="Admin">
                                                    <i><?php if($value['is_comment']==1){  echo $value['date']; } ?></i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Admin</i>
                                                        <p>
                                                           <?php if($value['is_comment']==1){  echo $value['comment']; } ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </li><?php } else if($value['is_comment']==2) { ?>
                                            <li class="clearfix odd">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo base_url(); ?>/image/icon.png" alt="Admin">
                                                    <i><?php if($value['is_comment']==2){  echo $value['date']; } ?></i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Admin</i>
                                                        <p>
                                                           <?php if($value['is_comment']==2){  echo $value['comment']; } ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </li><?php } ?>
                                            
                                          
                                        <?php } ?>
                                        </ul>
                                        <div class="row">
                                            <div class="col-sm-9 chat-inputbar">
                                                <input type="text" class="form-control chat-input" placeholder="Enter your text" id="text">
                                            </div>
                                            <div class="col-sm-3 chat-send">
                                                <button type="submit" class="btn btn-md btn-info btn-block waves-effect waves-light" onclick="send();">Send</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div> <!-- end col-->
                     
                            <!-- Todos app -->
                            <div class="col-lg-6">
                                <div class="card-box">
                                    <h4 class="m-t-0 m-b-20 header-title text-center"><b>User Details</b></h4>
                                    <div class="text-center">
                                        <div class="member-card">
                                            
                                            <div class="thumb-xl member-thumb m-b-10 center-block">
                                                        <img src="<?php echo $profession[0]['u_image'] ?>" class="img-circle img-thumbnail" alt="profile-image" style="height: 100px;width: 100px">
                                                        <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i>
                                                    </div>
                                            <div class="">
                                                <h4 class="m-b-5"><?php echo $profession[0]['u_name']; ?></h4>
                                                <p class="text-muted"><?php  $id=$profession[0]['id'];
                                                $where='user_id';
                                                $table='query';
                                                $query =$this->Adminmodel->select_comm_where($where,$id,$table); 
                                                $id=$query[0]['category'];
                                                $where='id';
                                                $table='category';
                                                $category =$this->Adminmodel->select_comm_where($where,$id,$table);

                                                echo $category[0]['name']; ?> </p>
                                            </div>
                                                    <div class="text-left">
                                                        <p class="text-muted font-13"><strong>Full Name :</strong> <span class="m-l-15"><?php echo $profession[0]['u_name']; ?></span></p>

                                                        <p class="text-muted font-13"><strong>Mobile :</strong><span class="m-l-15"><?php echo $profession[0]['u_phone']; ?></span></p>

                                                        <p class="text-muted font-13"><strong>Email :</strong> <span class="m-l-15"><?php echo $profession[0]['u_email']; ?></span></p>
<!-- 
                                                        <p class="text-muted font-13"><strong>Age :</strong> <span class="m-l-15">30</span></p>

                                                        <p class="text-muted font-13"><strong>Gender :</strong> <span class="m-l-15">Male</span></p>

                                                        <p class="text-muted font-13"><strong>Address :</strong> <span class="m-l-15">Contrary to popular belief, Lorem Ipsum is not simply random text.</span></p>

                                                        <p class="text-muted font-13"><strong>About :</strong> <span class="m-l-15">Contrary to popular belief, Lorem Ipsum is not simply random text. Contrary to popular belief, Lorem Ipsum is not simply random text. </span></p> -->
                                                    </div>
                                                </div>

                                            </div> <!-- end card-box -->
                                </div>

                            </div> <!-- end col -->
                        </div> <!-- end row -->


                        

                    </div> <!-- container -->

                </div> <!-- content -->

          <input type="hidden" id="url" value="<?php echo base_url(); ?>">   
          <input type="hidden" id="queryid" value="<?php echo $comment[0]['query_id']; ?>">   
          <input type="hidden" id="userid" value="<?php echo $comment[0]['user_id']; ?>">   
          <input type="hidden" id="proid" value="<?php echo $comment[0]['is_assigned']; ?>">   

            </div>

 <?php
include 'footer.php';
 ?>
 <script type="text/javascript">
        function send(){
       
            var urls = $("#url").val();
            var text = $("#text").val();
            var userid = $("#userid").val();
            var proid = $("#proid").val();
            var queryid = $("#queryid").val();

            $.ajax({

                    type: "POST",

                    url: urls+"Admin/chat",

                    data: {userid:userid,proid:proid,text:text,queryid:queryid},

                    cache: false,

                    success: function(result){
                       window.location.reload();
                    }

                    });
        }
    </script>