
<!-- Top Bar End -->


<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul>
                <li class="has_sub">
                    <a href="<?php echo base_url('index.php/Admin/Dashboard'); ?>" class="waves-effect"><i class="mdi mdi-view-dashboard"></i><span>Administrator</span></a>
                </li>
                <li class="has_sub">
                    <a href="<?php echo base_url('index.php/Admin/Proffesional'); ?>" class="waves-effect"><i class="mdi mdi-briefcase"></i><span>Expert Panelist</span></a>
                </li>
                <li class="has_sub">
                    <a href="<?php echo base_url('index.php/Admin/User'); ?>" class="waves-effect"><i class="mdi mdi-account"></i><span> Applicant</span></a>
                </li>
                <li class="has_sub">
                    <a href="<?php echo base_url('index.php/Admin/profenquiry'); ?>" class="waves-effect"><i class="mdi mdi-account-card-details"></i><span>Enquiry for Experts </span> </a>
                </li>
                <li class="has_sub">
                    <a href="<?php echo base_url('index.php/Admin/direct'); ?>" class="waves-effect"><i class="mdi mdi-briefcase"></i><span>Enquiry For Admin </span></a>
                </li>
                <li class="has_sub">
                    <a href="<?php echo base_url('index.php/Admin/create'); ?>" class="waves-effect"><i class="mdi mdi-refresh"></i><span>Create Expert</span></a>
                </li>

                           <!--  <li class="has_sub">
                                <a href="<?php echo base_url('Admin/category'); ?>" class="waves-effect"><i class="mdi mdi-refresh"></i><span>Create Category</span></a>
                            </li> -->
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-google-pages"></i><span> Pages </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url('index.php/Admin/Slider'); ?>">Slider (Content)</a></li>
                                    <!-- <li><a href="<?php echo base_url('index.php/Admin/video'); ?>">Video</a></li> -->
                                    <li><a href="<?php echo base_url('index.php/Admin/About'); ?>">About (What We Do)</a></li>
                                    <li><a href="<?php echo base_url('index.php/Admin/Why'); ?>">Why Join ShareTCare</a></li>
                                    <li><a href="<?php echo base_url('index.php/Admin/steps'); ?>">Steps to follow</a></li>
                                    <li><a href="<?php echo base_url('index.php/Admin/Event'); ?>">Event</a></li>

                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>
                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->