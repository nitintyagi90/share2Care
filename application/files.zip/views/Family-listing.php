<?php

include 'header.php';
?>
<!--------------------------- Information Section Starts -------------->
    <section class="mg-tp-60">
        <div class="container">
            <div class="row">
                <div>
                    
                        <h3 class="heading-color text-center" >Support For Senior Citizens</h3>
                </div>
                <div class="col-md-12">
                    <p>Senior citizens are assets of the society and the country. They have gained vast experience in different walks of life after working hard, all these years, for development of the Nation. We need to serve them for all their needs like day-to-day living, healthcare, financial management (including pension and deposit schemes) and make them feel special.</p>
                    <p>In this direction Govt. of India also provides several benefits through its schemes like Tax benefits, Travel and Health care including facilities at hospitals, medical insurance, concessions for Train and Air travel, Tax benefits, Sr. Citizens pension Schemes, and others. Consultation shall extent help to them for any issue related to day-to-day need, and/or resolving any issue about various schemes.</p>
                </div>
            </div>
        </div>
    </section>
    <!-------------------- Information Section Ends ----------------------------------->

    <!-------- list -------->
    <section class="mg-top-bt">
        <div class="container">
            <?php 
            $id='1';
            $where='p_cat';
            $table='proffesional';
            $name=$this->Adminmodel->select_comm_where($where,$id,$table);
            foreach ($name as $value) {
                  if($value['p_active']==1) { 
               ?>
            <div class="row border-bt mg-top-bt">
                <div class="col-md-4 col-12">
                    <div class="img-boxsize">
                        <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                    </div>
                </div>
                <div class="col-md-6 col-12">
                    <h2><?php echo $value['p_name']; ?></h2>
                    <span><?php echo $value['p_destination']; ?></span>
                    <br />
                    <span><?php echo $value['p_experience']; ?> Years</span>
                    <p class="text-justify mt-1"><?php echo $value['p_description']; ?>.</p>
                </div>
                <?php if(!empty($_SESSION['sessionid'])){ ?>
                <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/1' );?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } else { ?>
                 <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/' .$value['id'].'/1');?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } ?>
            </div>
        <?php } }  ?>

          
        </div>
    </section>
    <!-------- list -------->
<?php
include 'footer.php';