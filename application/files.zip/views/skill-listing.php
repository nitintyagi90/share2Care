<?php

include 'header.php';
?>
<!--------------------------- Information Section Starts -------------->
<section class="mg-tp-60">
  <div class="container">
    <div class="row">
        <div>
            <h3 class="heading-color text-center">Skill Development</h3>
        </div>
        <div class="col-md-12">
            <p>Skill Development means developing yourself and your skill sets to add value for your own career development. Skills development is the process of <br>(1) identifying your skill gaps, and <br>(2) developing and honing these skills. It is important because your skills determine your ability to execute your plans with success.</p>
            <p>Skills and knowledge are the motivating factors of the financial growth and economic development of the country. Government of India has launched The National Skill Development Mission, in July 2015. The Mission has been developed to create convergence across sectors and States in terms of skill training activities.</p>
            <p>By consultation, you will identify the skills &amp; the step required to develop those skills to achieve your goals in life.</p>
            <p>The two main avenues for developing your skills are through the following:</p>
            <p>(a) Education and Training</p>
            <p>(b) Developmental Experiences</p>
        </div>
    </div>
</section>
<!-------------------- Information Section Ends ----------------------------------->


<!-------- list -------->
<section class="mg-top-bt">
    <div class="container">
      <?php 
      $id='10';
      $where='p_cat';
      $table='proffesional';
      $name=$this->Adminmodel->select_comm_where($where,$id,$table);
      foreach ($name as $value) {
       ?>
       <div class="row border-bt mg-top-bt">
        <div class="col-md-4 col-12">
            <div class="img-boxsize">

                <?php 
                if(isset($value['p_image']) && $value['p_image'] != base_url().'image/' )
                {
                    ?>
                    <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                    <?php
                }
                else
                {
                    ?>
                    <img style="width: 180px" src="<?php echo base_url() ?>/image/user.svg" class="img-responsive">
                    <?php
                }
                ?>

            </div>
        </div>
        <div class="col-md-6 col-12">
            <h2><?php echo $value['p_name']; ?></h2>
            <span><?php echo $value['p_destination']; ?></span><br />
            <span><?php echo $value['p_experience']; ?> Years</span>
            <p class="text-justify mt-1"><?php echo $value['p_description']; ?>.</p>
        </div>
        <?php if(!empty($_SESSION['sessionid'])){ ?>
            <div class="col-md-2 col-12">
                <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/10' );?>" class="bt-color">Submit Enquiry</a></div>
            </div>
        <?php } else { ?>
         <div class="col-md-2 col-12">
            <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/'.$value['id'].'/10' );?>" class="bt-color">Submit Enquiry</a></div>
        </div>
    <?php } ?>
</div>
<?php }  ?>
</div>
</section>
<!-------- list -------->
<?php
include 'footer.php';