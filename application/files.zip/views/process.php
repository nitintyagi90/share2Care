<?php

include 'header.php';
?>
  <section class="mg-tp-50">
  <div class="container">
    <div class="mainabt row">
<div class="col-md-8 col-sm-12">
                <h3 class="text-center heading-color">Process flow for submitting query</h3>
                <ul class="Process-list">
                  <?php echo $note[0]['note1']; ?>
               
                </ul>
            </div>
            <div class="col-md-4 col-sm-12">
                <img src="<?php echo $note[0]['note2']; ?>" class="img-responsive" style="margin-top: 23%;">
            </div>
  </div>
</section>
  
<?php
include 'footer.php';