<?php
include 'header.php';
?>



<section class="mg-tp-50" style="padding: : 8%;">
  <div class="container   box-wrapper">
   <div class="row">
     <div class="col-md-3"></div>
     <div class="col-md-6 col-sm-12 padd-login">
       <!-- <h3 class="heading-color text-center mg-bt-30">Submit Enquiry</h3> -->
       <h4 class="text-center">Create/Authenticate Applicants profile</h5>
        <div class="formsec pdd">
                         <!--  <span>Feel free to send us any questions you may have. We are happy to answer them.</span>
                          <br> -->
                          <form  method="post">
                          <!-- <div class="login_result error" style="display: none;"  >Your Account is Already Existed </div>
                    <div class="login success" style="display: none;"  >Thanks For Contacting us Team Will Contact us Shortly. </div>
                    <div class="login_result1 error1" style="display: none;"  >Password Not Matched</div> -->

                    <div class="form-group" style="margin-bottom: 0px;">
                      <label>Name</label>
                      <input type="text"  id="name" class="form-control" required>
                    </div>

                    <div class="form-group" style="margin-bottom: 0px;">
                      <label>Email</label>
                      <input type="email"  id="email" class="form-control" required>
                    </div>
                    <div class="form-group" style="margin-bottom: 0px;">
                      <label>Password</label>
                      <input type="Password"  id="pass" class="form-control" required>
                      <span style="float: right;   font-size: 14px;"><a href="<?php echo base_url('Share/forgot'); ?>" style="color: #9f0012; ">Forgot Password</a></span>
                    </div>
                    <div class="form-group" style="margin-bottom: 0px;" >
                      <label>Mobile</label>
<!-- 
                      <select>
                        <option value="">Select</option>

                        <?php
                        foreach ($country as $key => $value) {
                          ?>
                          <option value="<?php // echo $value['id'] ?>">(+ <?php // echo $value['phonecode'] ?>) <?php // echo $value['name'] ?></option>

                          <?php
                        }
                        ?>

                      </select> -->
                      <div>
                        <span style="position: absolute; z-index: 1; font-size: 14px; margin-top: 7px; left: 25px;">+ 91 - </span>
                        <input type="text" style="padding-left: 55px;" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" id="phone" name="phone" minlength="10" maxlength="10" class="form-control" onkeydown="if  (this.value.length==10 && event.keyCode == 13) otpclick()">
                      </div>





                               <!--  <div class="padd-l-43">
                                <button id="ourotp" type="button" class="btn btn-color text-center" onclick="otpclick()" href="javascript:void(0)" onclick="otpclick1();">Submit</button></div> -->
                                
                                <span id="ourotp"><a class="frgt" onclick="otpclick()" href="javascript:void(0)">Get OTP</a>
                                </span>

                                <span id="ourotp1" style="display: none;float: right;color: red;    font-size: 14px;">OTP Send Successfully</span>
                                <span id="ourotp4" style="display: none;float: right;color: red;    font-size: 14px;">Please enter Mobile No</span>
                              </div>
                              <div class="form-group" style="margin-bottom: 0px;">
                                <label>OTP</label>
                                <input type="text" id="addotp" name="otp" minlength="4" maxlength="4" class="form-control">
                                <div class="login_result1 error1" style="display: none;"  >Please Enter Valid  OTP</div>
                                <span id="ourotp2"><a class="frgt" onclick="otpclick2()" href="javascript:void(0)">Resend OTP</a></span>
                                <span id="ourotp3" style="display: none;float: right;color: red;font-size: 14px;">Resend OTP Send Successfully</span>
                                <span id="ourotp8" style="display: none;float: right;color: red;    font-size: 14px;">Please enter Mobile No</span>
                              </div>
                              <input type="hidden" id="url" value="<?php echo base_url(); ?>index.php/">

                              <div class="text-center" style="margin-bottom: 10px;margin-top: 10px;">

                                <input type="hidden" id="urls" value="<?php echo base_url(); ?>index.php/">

                                <div class="padd-l-20">
                                  <button type="button" class="btn btn-color text-center" onclick="otpclick1();">Submit</button></div></div>

                                </form>
                              </div>
                            </div> 
                            <div class="col-md-3"></div>
                          </div>
                        </div>  
                      </section>



                      <script type="text/javascript">
                        $(document).on('submit', '#loginform',function(e){
                          e.preventDefault();

                          var formData = new FormData($(this)[0]);
                          var urls=$('#url').val();
                          var phone=$('#phone').val();

                          $.ajax({
                            url: urls+'Share/newuser1',
                            type: 'POST',
                            data:formData,
                            contentType: false,
                            processData: false,
                            success: function(data) {

                              if(data=='pass'){
                                $('.login_result2.error2').css('color', 'red');
                                $('.login_result2.error2').show();
                              }else if(data=='email'){
                                $('.login_result2.error2').css('color', 'red');
                                $('.login_result.error').show();
                              }else{
                               $('.login.success').css('color', 'red');
                               $('.login.success').show();
                               window.setTimeout(function() {
                                window.location.href=urls+'Share/index';}, 3000);
                             }
                           }
                         });
                        });

                      </script>
                      <script type="text/javascript">
                        function otpclick2() {

                          var mobile=$("#phone").val();

                          if(mobile==''){
                           $("#ourotp8").show();

                         }else{
                           var urls = $("#url").val();



                           $.ajax({

                            type: "POST",

                            url: urls+"Share/newotp",

                            data: {mobiles:mobile},


                            cache: false,

                            success: function(result){

                             $("#ourotp2").hide();
                             $("#ourotp8").hide();
                             $("#ourotp3").show();
                           }
                         });
                         }
                       }
                     </script>
                     <script type="text/javascript">
                      function otpclick() {

                        var mobile=$("#phone").val();

                        if(mobile==''){
                         $("#ourotp4").show();

                       }else{
                         var urls = $("#url").val();



                         $.ajax({

                          type: "POST",

                          url: urls+"Share/newotp",

                          data: {mobiles:mobile},


                          cache: false,

                          success: function(result){

                           $("#ourotp").hide();
                           $("#ourotp4").hide();
                           $("#ourotp1").show();

                         }
                       });
                       }
                     }
                   </script>


                   
                   <script type="text/javascript">
                    function otpclick1() {

                      var mobile=$("#phone").val();
                      var name=$("#name").val();
                      var otpfetch=$("#addotp").val();
                      var email=$("#email").val();
                      var pass=$("#pass").val();
                      if(mobile==''){
                        alert("Please enter mobile no");exit();
                      }

                      if(name==''){
                        alert("Please enter name");exit();
                      }

                      if(email==''){
                        alert("Please enter email id");exit();
                      }
                      if(pass==''){
                        alert("Please enter password");exit();
                      }
                      if(otpfetch==''){
                        alert("Please enter otp");exit();
                      }


                      var urls = $("#url").val();
                      $.ajax({
                        type: "POST",
                        url: urls+"Share/fetchotp",
                        data: {otpfetch:otpfetch,mobile:mobile,email:email,pass:pass,name:name},
                        cache: false,
                        success: function(result){
//alert(result);exit();
if(result=='enter'){
  alert("Please enter valid email or password.");exit();
}else if(result=='invalid'){
  alert("Please enter valid OTP.");exit();
}
else{
  window.location.href = urls+"Share/query";
}
   // 


 }

});

                    }
                  </script>


                  <?php
                  include 'footer.php';
                  ?>