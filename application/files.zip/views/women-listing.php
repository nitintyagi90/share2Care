<?php

include 'header.php';
?>

<!--------------------------- Information Section Starts -------------->
<section class="mg-tp-60">
  <div class="container">
    <div class="row">
        <div>
          <h2 class="heading-color text-center">Women Care</h2>
      </div>
      <div class="col-md-12">
        <p>From a young age, many girls face gender discrimination. This can
            impact their health, well-being, education, career options, and other life goals. Thus women
        are especially vulnerable to poverty and economic insecurity.</p>
        <p>By women empowerment, the number of women entrepreneurs, small-business owners,
            community workers, educators, health sector workers, and corporate leaders continues to
        rise, which contributes to the growth of our economy.</p>
    </div>
</div>
</section>
<!-------------------- Information Section Ends ----------------------------------->


<!-------- list -------->
<section class="mg-top-bt">
    <div class="container">
     <?php 
     $id='8';
     $where='p_cat';
     $table='proffesional';
     $name=$this->Adminmodel->select_comm_where($where,$id,$table);
     foreach ($name as $value) {
      if($value['p_active']==1) { 

         ?>
         <div class="row border-bt mg-top-bt">
            <div class="col-md-4 col-12">
               <div class="img-boxsize">

                    <?php 
                    if(isset($value['p_image']) && $value['p_image'] != base_url().'image/' )
                    {
                        ?>
                        <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                        <?php
                    }
                    else
                    {
                        ?>
                        <img style="width: 180px" src="<?php echo base_url() ?>/image/user.svg" class="img-responsive">
                        <?php
                    }
                    ?>

                </div>
            </div>
            <div class="col-md-6 col-12">
                <h2><?php echo $value['p_name']; ?></h2>
                <span><?php echo $value['p_destination']; ?></span><br />
                <span><?php echo $value['p_experience']; ?> Years</span>
                <p class="text-justify mt-1"><?php echo $value['p_description']; ?>.</p>
            </div>
            <?php if(!empty($_SESSION['sessionid'])){ ?>
                <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/8' );?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } else { ?>
               <div class="col-md-2 col-12">
                <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/'.$value['id'].'/8' );?>" class="bt-color">Submit Enquiry</a></div>
            </div>
        <?php } ?>
    </div>
<?php }  } ?>
</div>
</section>
<!-------- list -------->
<?php
include 'footer.php';