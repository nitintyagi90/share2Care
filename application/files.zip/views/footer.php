 <section class="ftr2">
        <div class="container">
            <p class="text-center">Copyright &copy; 2018 <span>Share2Care</span>. All Rights Reserved</p>
        </div>
    </section>
    <!-------------- footer-copyright-end ------------->
	</div>

    <!-- javascript -->
    <script type="text/javascript">
        $('#carouselHacked').carousel();
    </script>

    <script type="text/javascript">
    	// global vars
var winWidth = $(window).width();
var winHeight = $(window).height();

// set initial div height / width
$('.Wrapper').css({
    'width': winWidth,
'height': winHeight,
});

// make sure div stays full width/height on resize
$(window).resize(function(){
    $('.Wrapper').css({
    'width': winWidth,
    'height': winHeight,
});
});
    </script>
</body>
</html>