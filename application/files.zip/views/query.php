<!-- <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script> -->

<?php

include 'header.php';
?>

<section class="" style="margin-bottom: 2%;">
  <div class="container">
    <div class="mainabt">
      <h3 class="heading-color text-center">Submit Applicant’s Enquiry</h3></div>
      <div class="col-md-6">
        <h4 class="text-left">Create/Authenticate Applicants profile</h3>
          <ul class="Process-list">
            <li>On submitting enquiry by “Submit Enquiry”, you will receive acknowledgement (SMS/Email).</li>
            <li>You will receive solution as advised by the concerned subject matter expert.</li>
            <li>If you need further guide, please revert back to us.</li>

          </ul>
        </div>
        <?php 
        $id=$_SESSION['sessionid'];
        $where='id';
        $table='Users';
        $user =$this->Adminmodel->select_comm_where($where,$id,$table);
        ?>
        <div class="col-md-offset-1 col-md-5">
          <form id="loginform1" method="post">
            <div class="form-group">
              <label for="name">Name<sup>*</sup></label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Enter your Name"required value="<?php echo $user[0]['u_name']; ?>">
            </div>
            <div class="row" style="margin-bottom: 3%;">
              <div class="col-12 col-md-6">
                <label for="name">Mobile Number<sup>*</sup></label>
                <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter your Mobile Number"required  value="<?php echo $user[0]['u_phone']; ?>" readonly>
              </div>
              <div class="col-12 col-md-6">
               <label for="name">Email<sup>*</sup></label>
               <input type="email" class="form-control" id="email" name="email" placeholder="Enter your Email"required  value="<?php echo $user[0]['u_email']; ?>" readonly>
             </div>
           </div>

           <div class="form-group">
            <label for="name">Address<sup>*</sup></label>
            <input type="text" class="form-control" id="address" name="address" placeholder="Enter your Address"required  value="<?php echo $user[0]['u_address']; ?>">
          </div>
          <div class="row" style="margin-bottom: 3%;">

            <div class="col-12 col-md-6">
              <label for="name">State<sup>*</sup></label>
              <!--  <input type="text" class="form-control" name="state" placeholder="Enter your State"required  value="<?php echo $user[0]['u_state']; ?>"> -->
              <select name="state" class="form-control option-list" required onchange="cityy()" id="cit">
                <option value="" disabled="">---- Select ----</option>
                <?php foreach ($states as  $values) {  ?>  

                  <option value="<?php echo $values['id']; ?>" <?php if($values['id']==$user[0]['u_state']){echo "selected"; } ?>><?php echo $values['name']; ?></option>


                <?php } ?>
              </select>
            </div>
            <div class="col-12 col-md-6">
              <label for="name">City<sup>*</sup></label>
              <select name="city" class="form-control option-list" required id="cit1">
                <option value="" disabled="">---- Select ----</option>
                <?php 
                $id= $user[0]['u_state'];
                $where='state_id';
                $table='cities';
                $city =$this->Adminmodel->select_comm_where($where,$id,$table);
                ?>

                <?php foreach ($city as  $values) {  ?>  

                  <option value="<?php echo $values['id']; ?>" <?php if($values['id']==$name[0]['u_city']){echo "selected"; } ?>><?php echo $values['name']; ?></option>

                <?php } ?>
              </select>
              <!-- <input type="text" name="city" class="form-control" placeholder="Enter your City"required  value="<?php // echo $user[0]['u_city']; ?>"> -->
            </div>
          </div>
          <div class="form-group">
            <label for="name">Choose Category<sup>*</sup></label>
            <select name="cat" class="form-control option-list" required onchange="expertp()" id="exp">
              <option>---- Select ----</option>
              <?php foreach ($message as  $value) {  ?>  
                <option value="<?php echo $value['id']; ?>" ><?php echo $value['name']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group" >
            <label for="name">Choose Expert </label>
            <select name="expid" class="form-control option-list" id="exp1">
              <option value="">---- Select ----</option>

            </select>
          </div>
          <div class="form-group">
            <label>Your Enquiry<sup>*</sup></label>
            <textarea class="form-control" id="message" rows="3" name="comment" required></textarea>
          </div>
          <div class="text-center mt-4">
            <button type="submit" class="btn btn-color">Submit</button>
          </div>
          <div class="alert alert-success alert-dismissable" style="display: none;">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            Success! Query sent successfully.
          </div>
          <div class="login_result2 error2" style="display: none;">enquiry submit</div>

          <input type="hidden" id="url" value="<?php echo base_url(); ?>index.php/">
        </form>
      </div>
    </div>
  </section>
  <input type="hidden" id="url" value="<?php echo base_url(); ?>index.php/">
  <?php
  include 'footer.php';
  ?>

  <script>
    function expertp(){
      var urls=$("#url").val();
      var catid= $("#exp").val();
      $.ajax({
        type: "POST",
        url: urls+"Share/cati",
        data: {id:catid},
        cache: false,
        success: function(result){
             // alert(result);
             $("#exp1").html(result);
           }
         });
    }




    function cityy(){
      var urls=$("#url").val();
      var catid= $("#cit").val();
      $.ajax({
        type: "POST",
        url: urls+"Share/citycat",
        data: {id:catid},
        cache: false,
        success: function(result){
           // alert(result);exit();
           $("#cit1").html(result);
         }
       });
    }
  </script>
  <script type="text/javascript">
    $(document).on('submit', '#loginform1',function(e){
      e.preventDefault();

      var formData = new FormData($(this)[0]);

      console.log(formData);

      var urls=$('#url').val();
      $.ajax({
        url: urls+'Share/addquery',
        type: 'POST',
        data:formData,
        contentType: false,
        processData: false,
        success: function(data) {
         $(".alert").hide().show('medium');

         console.log(data);

         window.location.href = urls+"Share/myquery/";

        //location.reload();
      /*  if(data=='pass'){
            $('.login_result2.error2').css('color', 'red');
                $('.login_result2.error2').show();
        
        }else if(data=='session'){
           $('.login.success').css('color', 'red');
                $('.login.success').show();
                window.setTimeout(function() {
          window.location.href=urls+'Share/login';});
        }*/
       /* else{
            alert(data);
           $('.login.success').css('color', 'red');
                $('.login.success').show();
                window.setTimeout(function() {
         // window.location.href=urls+'Share/query';}, 300);
       }*/
       // 
     }
   });
    });

  </script>