<?php

include 'header.php';
?>
<!--------------------------- Information Section Starts -------------->
<section class="mg-tp-60">
  <div class="container">
    <div class="row">
        <div>
          <h3 class="heading-color text-center" >Health Care</h3>
      </div>
      <div class="col-md-12">
        <p>We are also having experts in medical field, supported by Physicians as well as Physiotherapists. You can get consultation from our expert doctors, advising you on primary health care. This will ensure that you have access to the solution of your problems, which you need, without visiting a Doctor or Physiotherapist. Also, your counsellor will discuss options with you in order to help you find the appropriate treatment for your needs.</p>
        <p>However, these issues may sometimes need more of physical care than counseling. For complex health treatment beyond counseling, our expert may advise you for right treatment.</p>
        <p>The Health care consultation may also be useful during Pregnancy, Childbirth &amp; Newborn Care. Professional and confidential health services are aimed to keep you comfortable and able to achieve your goals.</p>
    </div>
</div>
</section>
<!-------------------- Information Section Ends ----------------------------------->


<!-------- list -------->
<section class="mg-top-bt">
    <div class="container">
     <?php 
     $id='6';
     $where='p_cat';
     $table='proffesional';
     $name=$this->Adminmodel->select_comm_where($where,$id,$table);
     foreach ($name as $value) {
      if($value['p_active']==1) { 

        print_r($value);

        ?>
        <div class="row border-bt mg-top-bt">
            <div class="col-md-4 col-12">
                <div class="img-boxsize">

                    <?php 
                    if(isset($value['p_image']) && $value['p_image'] != '')
                    {
                        ?>
                        <img src="<?php echo $value['p_image']; ?>" class="img-responsive">
                        <?php
                    }
                    else
                    {
                        ?>
                        <img style="width: 180px" src="<?php echo base_url() ?>/image/doctor.svg" class="img-responsive">
                        <?php
                    }
                    ?>

                </div>
            </div>
            <div class="col-md-6 col-12">
                <h2><?php echo $value['p_name']; ?></h2>
                <span><?php echo $value['p_destination']; ?></span><br />
                <span><?php echo $value['p_experience']; ?> Years</span>
                <p class="text-justify mt-1"><?php echo $value['p_description']; ?>.</p>
            </div>
            <?php if(!empty($_SESSION['sessionid'])){ ?>
                <div class="col-md-2 col-12">
                    <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/proquery/'.$value['id'].'/7' );?>" class="bt-color">Submit Enquiry</a></div>
                </div>
            <?php } else { ?>
             <div class="col-md-2 col-12">
                <div class="text-center top-space"><a href="<?php echo base_url('index.php/Share/loginuser/'.$value['id'].'/7' );?>" class="bt-color">Submit Enquiry</a></div>
            </div>
        <?php } } ?>
    </div>
<?php }  ?>
</div>
</section>
<!-------- list -------->
<?php
include 'footer.php';